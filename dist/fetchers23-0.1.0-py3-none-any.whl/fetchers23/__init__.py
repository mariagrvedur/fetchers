import fetchers.get_all_links as get_all_links

__all__ = ["get_all_links"]
